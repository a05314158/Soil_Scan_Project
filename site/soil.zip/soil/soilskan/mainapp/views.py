# views.py

from django.shortcuts import render

def index(request):
    return render(request, 'mainapp/html/index.html')

def about(request):
    return render(request, 'mainapp/html/about.html')

def services(request):
    return render(request, 'mainapp/html/services.html')

def contact(request):
    return render(request, 'mainapp/html/contact.html')
